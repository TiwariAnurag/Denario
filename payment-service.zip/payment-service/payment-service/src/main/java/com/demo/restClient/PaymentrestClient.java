package com.demo.restClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.demo.bean.UserDetails;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class PaymentrestClient {
	
	
	@Value("${user.service.url}")
	public String userServiceUrl;
	
	
	
	/**
	 * Gets the player details.
	 *
	 * @param playerId the player id
	 * @return the player details
	 */
	public UserDetails getUserDetails(Long userId) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		UserDetails userDetails=null;
		headers.setContentType(MediaType.APPLICATION_JSON);
		org.springframework.http.HttpEntity<String> entity = new org.springframework.http.HttpEntity<>(headers);
		ResponseEntity<String> res = null;

		try {
			String url = userServiceUrl+userId;
			restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());
			res = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
			if(res.getStatusCode().equals(HttpStatus.OK)) {
			String detials = res.getBody();
			userDetails = new ObjectMapper().readValue(detials, UserDetails.class); 
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userDetails;

	}

}
