package com.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.bean.PaymentDetails;
import com.demo.bean.PaymentDetailsRequest;
import com.demo.service.IPaymentService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


/**
 * The Class PaymentController.
 */
@SuppressWarnings("rawtypes")
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("payment/api/v1/")
@Api(value = "Payment API", description = "Operations pertaining to Payment Service ")
public class PaymentController {

	/** The payment service. */
	@Autowired
	private IPaymentService paymentService;

	/**
	 * Save user.
	 *
	 * @param paymentModel  the payment model
	 * @param bindingResult the binding result
	 * @return the org.springframework.http. response entity
	 */
	@SuppressWarnings("unchecked")
	@ApiOperation(value = "Create a payment", response = PaymentDetails.class)
	@PostMapping(value = "")
	public org.springframework.http.ResponseEntity saveUser(@Valid @RequestBody PaymentDetailsRequest paymentModel,
			BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			List<String> errorMsgs = getBindingResultMessages(bindingResult);
			return new ResponseEntity(errorMsgs, HttpStatus.BAD_REQUEST);

		}
		PaymentDetails pd = paymentService.save(paymentModel);
		if (pd == null) {
			return new ResponseEntity(pd, HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity(pd, HttpStatus.OK);
	}

	/**
	 * Updatepayment details.
	 *
	 * @param paymentDetails     the payment details
	 * @param paymentid          the paymentid
	 * @param httpServletRequest the http servlet request
	 * @return the response entity
	 */
	@SuppressWarnings("unchecked")
	@ApiOperation(value = "Update a payment details", response = PaymentDetails.class)
	@PutMapping(value = "/{paymentid}")
	public ResponseEntity updatepaymentDetails(@RequestBody PaymentDetails paymentDetails,
			@PathVariable("paymentid") Long paymentid) {
		Optional<PaymentDetails> response = paymentService.isExists(paymentid);
		if (response.isPresent()) {
			PaymentDetails result = paymentService.update(paymentDetails);
			if (result != null) {
				return new ResponseEntity(result, HttpStatus.OK);
			}
		}
		return new ResponseEntity(paymentDetails, HttpStatus.BAD_REQUEST);

	}

	/**
	 * Find all payment.
	 *
	 * @param id            the id
	 * @param date          the date
	 * @param startTime     the start time
	 * @param endTime       the end time
	 * @param paymentStatus the payment status
	 * @return the response entity
	 */
	@SuppressWarnings("unchecked")
	@ApiOperation(value = "Fetch Payment Details", response = PaymentDetails.class)
	@GetMapping(value = "")
	public ResponseEntity findAllPayment(@RequestParam("id") Long id,
			@RequestParam(value = "date", required = false) Long date,
			@RequestParam(value = "startTime", required = false) Long startTime,
			@RequestParam(value = "endTime", required = false) Long endTime,
			@RequestParam(value = "paymentStatus", required = false) String paymentStatus) {
		List<PaymentDetails> pdList = paymentService.getAllPayment(id, date, startTime, endTime);
		if (pdList.isEmpty()) {
			return new ResponseEntity(pdList, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity(pdList, HttpStatus.OK);
	}

	/**
	 * Gets the binding result messages.
	 *
	 * @param bindingResult the binding result
	 * @return the binding result messages
	 */
	public List<String> getBindingResultMessages(BindingResult bindingResult) {
		List<String> messageList = new ArrayList<String>();
		for (Object object : bindingResult.getAllErrors()) {
			if (object instanceof FieldError) {
				FieldError fieldError = (FieldError) object;
				String message = fieldError.getField() + " " + fieldError.getDefaultMessage();
				messageList.add(message);
			}
		}
		return messageList;
	}
}
