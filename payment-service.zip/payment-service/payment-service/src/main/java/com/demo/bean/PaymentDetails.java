package com.demo.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "payment_details")
@SequenceGenerator(name = "payment_sequence", sequenceName = "payment_sequence", allocationSize = 1)
public class PaymentDetails {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_sequence")
	private Long pId;

	private Long userId;

	private Double amount;

	private Long date = new Date().getTime();

	@Enumerated(EnumType.STRING)
	private PaymentType type;

	public Long getpId() {
		return pId;
	}

	public void setpId(Long pId) {
		this.pId = pId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Long getDate() {
		return date;
	}

	public void setDate(Long date) {
		this.date = date;
	}

	public PaymentType getType() {
		return type;
	}

	public void setType(PaymentType type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "PaymentDetails [pId=" + pId + ", userId=" + userId + ", amount=" + amount + ", date=" + date + ", type="
				+ type + "]";
	}

	public PaymentDetails() {

	}

}
