package com.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.bean.PaymentDetails;

public interface IPaymentDustomDao  {

	List<PaymentDetails> findAllPaymentByFilter(Long id, Long date, Long startTime, Long endTime);
	
	

}
