package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.bean.PaymentDetails;
import com.demo.bean.PaymentDetailsResponse;
import com.demo.bean.UserDetails;
import com.demo.bean.UserRegModel;
import com.demo.repository.IuserRepo;
import com.demo.restClient.UserrestClient;

/**
 * @author Anurag Tiwari
 *
 */
/**
 * @author Anurag Tiwari
 *
 */
@Service("userService")
public class UserServiceImpl implements IuserService {

	@Autowired
	private IuserRepo userDao;
	
	@Autowired
	private UserrestClient restClient;

	@Override
	public UserDetails save(UserRegModel userModel) {
		UserDetails ud = new UserDetails();
		ud.setActive(Boolean.TRUE);
		ud.setAge(userModel.getAge());
		ud.setEmail(userModel.getEmail());
		ud.setfName(userModel.getfName());
		ud.setGender(userModel.getGender());
		ud.setlName(userModel.getlName());
		ud.setPhone(userModel.getPhone());
		return userDao.save(ud);
	}

	@Override
	public List<UserDetails> getAllUser() {
		return userDao.findAll();
	}

	@Override
	public Optional<UserDetails> getUser(Long userId) {
		return userDao.findById(userId);
	}

	@Override
	public UserDetails userPayment(PaymentDetails paymentDetails) {
		PaymentDetailsResponse res = restClient.getPayment(paymentDetails);
		if (res != null) {
			Optional<UserDetails> userDetails = userDao.findById(paymentDetails.getUserId());
			if(res != null) {	
				userDetails.get().setPaymentStatus("COMPLETED");
			} else {
				userDetails.get().setPaymentStatus("FAILURE");
			}
			return userDao.save(userDetails.get());
		}
		return null;
		

	}

}
