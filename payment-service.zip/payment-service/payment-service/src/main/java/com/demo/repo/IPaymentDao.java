package com.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.bean.PaymentDetails;

public interface IPaymentDao extends JpaRepository<PaymentDetails, Long>{

}
