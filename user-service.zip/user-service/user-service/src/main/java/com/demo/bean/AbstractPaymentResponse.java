package com.demo.bean;

public class AbstractPaymentResponse {
	private Object responseCode;
	private PaymentDetailsResponse data;
	private Object args;

	public Object getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(Object responseCode) {
		this.responseCode = responseCode;
	}

	public PaymentDetailsResponse getData() {
		return data;
	}

	public void setData(PaymentDetailsResponse data) {
		this.data = data;
	}

	public Object getArgs() {
		return args;
	}

	public void setArgs(Object args) {
		this.args = args;
	}

}
