package com.demo.bean;

public enum PaymentType {

	DR,CR;
}
