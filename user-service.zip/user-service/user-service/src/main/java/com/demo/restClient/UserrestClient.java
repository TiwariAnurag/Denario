package com.demo.restClient;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.demo.bean.AbstractPaymentResponse;
import com.demo.bean.PaymentDetails;
import com.demo.bean.PaymentDetailsResponse;
import com.demo.bean.UserDetails;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class UserrestClient {

	@Value("${payment.service.url}")
	public String paymentServiceUrl;

	public PaymentDetailsResponse getPayment(PaymentDetails pd) {
		RestTemplate restTemplate = new RestTemplate();
		PaymentDetailsResponse response = new PaymentDetailsResponse();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		ResponseEntity<String> res = null;

		org.springframework.http.HttpEntity<Object> entity = new org.springframework.http.HttpEntity<>(pd, headers);
		try {

			String url = paymentServiceUrl;
			restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());

			res = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
			if (res.getStatusCode().equals(HttpStatus.OK)) {
				String responses = res.getBody();
				response = new ObjectMapper().readValue(responses, PaymentDetailsResponse.class);
				return response;
			}
		} catch (Exception e) {

		}
		return null;

	}

}
