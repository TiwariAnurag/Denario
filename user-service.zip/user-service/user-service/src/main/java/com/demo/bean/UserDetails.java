package com.demo.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "user_details")
@SequenceGenerator(name = "user_sequence", sequenceName = "user_sequence", allocationSize = 1)
public class UserDetails {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_sequence")
	Long userId;

	String fName;

	String lName;

	String gender;

	float age;

	String email;

	String phone;

	@Column(columnDefinition = "varchar(255) default 'true'")
	Boolean active;

	Long creation_date = new Date().getTime();

	Long last_access_date = new Date().getTime();

	String paymentStatus = "ACTIVE";

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public float getAge() {
		return age;
	}

	public void setAge(float age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Long getCreation_date() {
		return creation_date;
	}

	public Long getLast_access_date() {
		return last_access_date;
	}


	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	@Override
	public String toString() {
		return "UserDetails [userId=" + userId + ", fName=" + fName + ", lName=" + lName + ", gender=" + gender
				+ ", age=" + age + ", email=" + email + ", phone=" + phone + ", active=" + active + ", creation_date="
				+ creation_date + ", last_access_date=" + last_access_date + ", paymentStatus=" + paymentStatus + "]";
	}

	public UserDetails() {
		
	}
	
	

}
