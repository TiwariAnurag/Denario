package com.demo.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.demo.bean.PaymentDetails;
import com.demo.bean.PaymentDetailsRequest;
import com.demo.bean.PaymentType;
import com.demo.bean.UserDetails;
import com.demo.repo.IPaymentDao;
import com.demo.repo.IPaymentDustomDao;
import com.demo.restClient.PaymentrestClient;

@SuppressWarnings("deprecation")
@RunWith(MockitoJUnitRunner.Silent.class)
public class PaymentServiceTest {

	@InjectMocks
	PaymentServiceImpl paymentServiceImpl;

	@Mock
	IPaymentDao paymentDao;

	@Mock
	IPaymentDustomDao paymentCustomDao;
	
	@Mock
	PaymentrestClient paymentClient;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void save() {
		UserDetails userInfo = getUserDetails();
		Mockito.lenient().when(paymentClient.getUserDetails(1l)).thenReturn(userInfo);
		Mockito.lenient().when(paymentDao.save(getPaymentInfo())).thenReturn(getPaymentInfo());
		paymentServiceImpl.save(getpaymode());
	}
	
	
	@Test
	public void isExistTest() {
		Mockito.lenient().when(paymentDao.findById(1l)).thenReturn(Optional.of(getPaymentInfo()));
		paymentServiceImpl.isExists(1l);
	}
	
	@Test
	public void updateTest() {
		Mockito.lenient().when(paymentDao.save(getPaymentInfo())).thenReturn(getPaymentModel());
		paymentServiceImpl.update(getPaymentInfo());
	}
	
	@Test
	public void getAllFilterTest() {
		Long date= new Date().getTime();
		List<PaymentDetails> ll = new ArrayList();
		ll.add(getPaymentInfo());
		Mockito.lenient().when(paymentCustomDao.findAllPaymentByFilter(1l, date, date, date)).thenReturn(ll);
		paymentServiceImpl.getAllPayment(1l, date, date, date);
	}
	
	private PaymentDetails getPaymentInfo() {
	PaymentDetails pd= new PaymentDetails();
	pd.setAmount(10d);
	pd.setType(PaymentType.CR);
	pd.setUserId(1l);
	return pd;
	}
	

	private UserDetails getUserDetails() {
		UserDetails userDetails = new UserDetails();
		userDetails.setActive(true);
		userDetails.setAge(19f);
		userDetails.setEmail("abc");
		userDetails.setfName("fname");
		userDetails.setGender("Male");
		userDetails.setUserId(1l);
		return userDetails;
	}

	private PaymentDetailsRequest getpaymode() {
		PaymentDetailsRequest paymentMode = new PaymentDetailsRequest();
		paymentMode.setAmount(10d);
		paymentMode.setType(PaymentType.DR);
		paymentMode.setUserId(1l);
		return paymentMode;
	}

	private PaymentDetails getPaymentModel() {
		PaymentDetails pd = new PaymentDetails();
		pd.setAmount(10d);
		pd.setDate(new Date().getTime());
		pd.setpId(1l);
		pd.setType(PaymentType.CR);
		pd.setUserId(1l);
		return pd;

	}
}
