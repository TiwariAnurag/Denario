package com.demo.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.demo.bean.PaymentDetails;
import com.demo.bean.UserDetails;
import com.demo.bean.UserRegModel;

public interface IuserService {

	UserDetails save(UserRegModel userModel);

	List<UserDetails> getAllUser();

	Optional<UserDetails> getUser(Long userId);

	UserDetails userPayment(PaymentDetails paymentDetails);

}
