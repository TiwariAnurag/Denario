package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.bean.PaymentDetails;
import com.demo.bean.PaymentDetailsRequest;
import com.demo.bean.UserDetails;
import com.demo.repo.IPaymentDao;
import com.demo.repo.IPaymentDustomDao;
import com.demo.restClient.PaymentrestClient;


/**
 * The Class PaymentServiceImpl.
 */
@Service("paymentService")
public class PaymentServiceImpl implements IPaymentService {
	
	/** The payment client. */
	@Autowired
	private PaymentrestClient paymentClient;
	
	/** The payment dao. */
	@Autowired
	private IPaymentDao paymentDao;
	
	/** The payment custom dao. */
	@Autowired IPaymentDustomDao paymentCustomDao;

	/**
	 * Save.
	 *
	 * @param paymentModel the payment model
	 * @return the payment details
	 */
	@Override
	public PaymentDetails save(PaymentDetailsRequest paymentModel) {
		
		UserDetails userDetails = paymentClient.getUserDetails(paymentModel.getUserId());
		if(userDetails!= null) {
			PaymentDetails pd= new PaymentDetails();
			pd.setAmount(paymentModel.getAmount());
			pd.setType(paymentModel.getType());
			pd.setUserId(paymentModel.getUserId());
			return paymentDao.save(pd);
			
		}
		return null;
	}

	/**
	 * Checks if is exists.
	 *
	 * @param paymentid the paymentid
	 * @return the optional
	 */
	@Override
	public Optional<PaymentDetails> isExists(Long paymentid) {
		return paymentDao.findById(paymentid);
	}

	/**
	 * Update.
	 *
	 * @param paymentDetails the payment details
	 * @return the payment details
	 */
	@Override
	public PaymentDetails update(PaymentDetails paymentDetails) {
		return paymentDao.save(paymentDetails);
	}

	/**
	 * Gets the all payment.
	 *
	 * @param id the id
	 * @param date the date
	 * @param startTime the start time
	 * @param endTime the end time
	 * @return the all payment
	 */
	@Override
	public List<PaymentDetails> getAllPayment(Long id, Long date, Long startTime, Long endTime) {
		List<PaymentDetails> listdata =paymentCustomDao.findAllPaymentByFilter(id,date,startTime,endTime);
		return listdata;
	}

}
