package com.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.bean.UserDetails;

@Repository("userDao")
public interface IuserRepo  extends JpaRepository<UserDetails, Long>{

}
