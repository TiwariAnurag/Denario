package com.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.bean.PaymentDetails;
import com.demo.bean.UserDetails;
import com.demo.bean.UserRegModel;
import com.demo.service.IuserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * The Class UserController.
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("user/api/v1/")
@Api(value = "UserAPI", description = "Operations pertaining to user Service ")
public class UserController {

	/** The user service. */
	@Autowired
	IuserService userService;

	/**
	 * Save user.
	 *
	 * @param userModel     the user model
	 * @param bindingResult the binding result
	 * @return the org.springframework.http. response entity
	 */
	@ApiOperation(value = "Create a User", response = UserDetails.class)
	@PostMapping(value = "")
	public org.springframework.http.ResponseEntity saveUser(@Valid @RequestBody UserRegModel userModel,
			BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			List<String> errorMsgs = getBindingResultMessages(bindingResult);
			return new ResponseEntity(errorMsgs, HttpStatus.BAD_REQUEST);

		}
		UserDetails ud = userService.save(userModel);

		return new ResponseEntity(ud, HttpStatus.OK);
	}

	/**
	 * List all user.
	 *
	 * @return the response entity
	 */
	@GetMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get all user", response = UserDetails.class)
	public ResponseEntity listAllUser() {

		List<UserDetails> udList = userService.getAllUser();
		return new ResponseEntity(udList, HttpStatus.OK);
	}

	/**
	 * User details.
	 *
	 * @param userId the user id
	 * @return the response entity
	 */
	@GetMapping(value = "/user", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get user Details", response = UserDetails.class)
	public ResponseEntity userDetails(@PathParam(value = "userId") Long userId) {

		Optional<UserDetails> udList = userService.getUser(userId);
		if (udList.isPresent()) {
			return new ResponseEntity(udList.get(), HttpStatus.OK);
		}
		return new ResponseEntity(udList, HttpStatus.NOT_FOUND);
	}

	@ApiOperation(value = "Create a payment", response = UserDetails.class)
	@PostMapping(value = "/payment")
	public org.springframework.http.ResponseEntity payment(@Valid @RequestBody PaymentDetails paymentDetails,
			BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			List<String> errorMsgs = getBindingResultMessages(bindingResult);
			return new ResponseEntity(errorMsgs, HttpStatus.BAD_REQUEST);

		}
		UserDetails ud = userService.userPayment(paymentDetails);
		if(ud!=null) {
			return new ResponseEntity(ud, HttpStatus.OK);
		}
		return new ResponseEntity(ud, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Gets the binding result messages.
	 *
	 * @param bindingResult the binding result
	 * @return the binding result messages
	 */
	public List<String> getBindingResultMessages(BindingResult bindingResult) {
		List<String> messageList = new ArrayList<String>();
		for (Object object : bindingResult.getAllErrors()) {
			if (object instanceof FieldError) {
				FieldError fieldError = (FieldError) object;
				String message = fieldError.getField() + " " + fieldError.getDefaultMessage();
				messageList.add(message);
			}
		}
		return messageList;
	}
}
