package com.demo.bean;

import java.util.Date;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

public class PaymentDetailsResponse {

	private Long pId;

	private Long userId;

	private Double amount;

	private Long date;

	@Enumerated(EnumType.STRING)
	private PaymentType type;

	public Long getpId() {
		return pId;
	}

	public void setpId(Long pId) {
		this.pId = pId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Long getDate() {
		return date;
	}

	public void setDate(Long date) {
		this.date = date;
	}

	public PaymentType getType() {
		return type;
	}

	public void setType(PaymentType type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "PaymentDetailsResponse [pId=" + pId + ", userId=" + userId + ", amount=" + amount + ", date=" + date
				+ ", type=" + type + "]";
	}

}
