package com.demo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.naming.factory.BeanFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.validation.BindingResult;

import com.demo.bean.PaymentDetails;
import com.demo.bean.PaymentDetailsRequest;
import com.demo.bean.PaymentType;
import com.demo.service.PaymentServiceImpl;

@SuppressWarnings("deprecation")
@RunWith(MockitoJUnitRunner.Silent.class)
public class PaymentControllerTest {

	@InjectMocks
	PaymentController paymentController;

	@Mock
	PaymentServiceImpl paymentServiceImpl;

	@Mock
	BeanFactory beanFactory;

	@Mock
	BindingResult mockBindingResult;

	@Test
	public void savePaymentvalidation() {
		PaymentDetails paymentdetials = getPaymentModel();
		Mockito.lenient().when(mockBindingResult.hasErrors()).thenReturn(true);
		Mockito.lenient().when(paymentServiceImpl.save(getpaymode())).thenReturn(paymentdetials);
		paymentController.saveUser(getpaymode(), mockBindingResult);
	}

	@Test
	public void savePayment() {
		PaymentDetails paymentdetials = getPaymentModel();
		Mockito.lenient().when(mockBindingResult.hasErrors()).thenReturn(false);
		Mockito.lenient().when(paymentServiceImpl.save(getpaymode())).thenReturn(paymentdetials);
		paymentController.saveUser(getpaymode(), mockBindingResult);
	}

	@Test
	public void updatepayment() {
		PaymentDetails paymentdetials = getPaymentModel();
		Mockito.lenient().when(paymentServiceImpl.isExists(1l)).thenReturn(Optional.of(paymentdetials));
		Mockito.lenient().when(paymentServiceImpl.update(paymentdetials)).thenReturn(paymentdetials);
		paymentController.updatepaymentDetails(paymentdetials, 1l);
	}

	@Test
	public void updatepaymentNullResponse() {
		PaymentDetails paymentdetials = getPaymentModel();
		Mockito.lenient().when(paymentServiceImpl.isExists(1l)).thenReturn(Optional.of(new PaymentDetails()));
		Mockito.lenient().when(paymentServiceImpl.update(paymentdetials)).thenReturn(paymentdetials);
		paymentController.updatepaymentDetails(paymentdetials, 1l);
	}

	@Test
	public void findAllTestBlankData() {
		Mockito.lenient().when(paymentServiceImpl.getAllPayment(1l, 12321321321l, 123213213l, 12321321321l))
				.thenReturn(new ArrayList<PaymentDetails>());
		paymentController.findAllPayment(1l, 12321321321l, 123213213l, 12321321321l, "DR");
	}

	@Test
	public void findAllTestData() {
		List<PaymentDetails> ll = new ArrayList<PaymentDetails>();
		ll.add(getPaymentModel());
		Mockito.lenient().when(paymentServiceImpl.getAllPayment(1l, 12321321321l, 123213213l, 12321321321l))
				.thenReturn(ll);
		paymentController.findAllPayment(1l, 12321321321l, 123213213l, 12321321321l, "DR");
	}

	private PaymentDetailsRequest getpaymode() {
		PaymentDetailsRequest paymentMode = new PaymentDetailsRequest();
		paymentMode.setAmount(10d);
		paymentMode.setType(PaymentType.DR);
		paymentMode.setUserId(1l);
		return paymentMode;
	}

	private PaymentDetails getPaymentModel() {
		PaymentDetails pd = new PaymentDetails();
		pd.setAmount(10d);
		pd.setDate(new Date().getTime());
		pd.setpId(1l);
		pd.setType(PaymentType.CR);
		pd.setUserId(1l);
		return pd;

	}
}
