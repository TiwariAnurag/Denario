package com.demo.service;

import java.util.List;
import java.util.Optional;

import com.demo.bean.PaymentDetails;
import com.demo.bean.PaymentDetailsRequest;

/**
 * The Interface IPaymentService.
 */
public interface IPaymentService {

	/**
	 * Save.
	 *
	 * @param paymentModel the payment model
	 * @return the payment details
	 */
	PaymentDetails save(PaymentDetailsRequest paymentModel);

	/**
	 * Checks if is exists.
	 *
	 * @param paymentid the paymentid
	 * @return the optional
	 */
	Optional<PaymentDetails> isExists(Long paymentid);

	/**
	 * Update.
	 *
	 * @param paymentDetails the payment details
	 * @return the payment details
	 */
	PaymentDetails update(PaymentDetails paymentDetails);

	/**
	 * Gets the all payment.
	 *
	 * @param id        the id
	 * @param date      the date
	 * @param startTime the start time
	 * @param endTime   the end time
	 * @return the all payment
	 */
	List<PaymentDetails> getAllPayment(Long id, Long date, Long startTime, Long endTime);

}
