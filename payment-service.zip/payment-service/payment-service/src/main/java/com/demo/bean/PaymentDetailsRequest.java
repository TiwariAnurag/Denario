package com.demo.bean;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;


public class PaymentDetailsRequest {
	
	@Positive
	private Long userId;
	
	@Positive
	private Double amount;
	
	
	@Enumerated(EnumType.STRING)
	private PaymentType type;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	
	public PaymentType getType() {
		return type;
	}

	public void setType(PaymentType type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "PaymentDetailsRequest [userId=" + userId + ", amount=" + amount + ", type=" + type
				+ "]";
	}

	
	
}
