package com.demo.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.demo.bean.PaymentDetails;

@Repository("paymentDao")
public class PaymentDaoImpl implements IPaymentDustomDao {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<PaymentDetails> findAllPaymentByFilter(Long id, Long date, Long startTime, Long endTime) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<PaymentDetails> cq = cb.createQuery(PaymentDetails.class);

		Root<PaymentDetails> book = cq.from(PaymentDetails.class);
		List<Predicate> predicates = addPredicates(id, date, startTime, endTime, cb, book);

		cq.where(predicates.stream().toArray(Predicate[]::new));

		return entityManager.createQuery(cq).getResultList();

	}

	private List<Predicate> addPredicates(Long id, Long date, Long startTime, Long endTime, CriteriaBuilder cb,
			Root<PaymentDetails> book) {
		List<Predicate> predicates = new ArrayList<>();

		if (id != null) {
			predicates.add(cb.equal(book.get("pId"), id));
		}
		if (date != null) {
			predicates.add(cb.equal(book.get("date"), date));
		}
		if (startTime != null && endTime != null) {
			predicates.add(cb.between(book.get("date"), startTime, endTime));
		}

		return predicates;
	}

}
